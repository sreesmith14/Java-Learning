package com.bbm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BbmApplication {

	public static void main(String[] args) {
		SpringApplication.run(BbmApplication.class, args);
	}

}
